package com.example.service;


import com.example.entity.User;
import com.example.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    // register a new user - returns saved user
    public User register(String username, String rawPassword) {
        String hashed = passwordEncoder.encode(rawPassword);
        User u = new User(username, hashed);
        return userRepository.save(u);
    }

    // find by username
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }

    // validate credentials (raw password checked against stored hash)
    public boolean validateCredentials(String username, String rawPassword) {
        Optional<User> opt = findByUsername(username);
        if (opt.isEmpty()) return false;
        User u = opt.get();
        return passwordEncoder.matches(rawPassword, u.getPassword());
    }
}
