package com.example.dto;



public class BookDTO {

    private Integer id;
    private String title;
    private String  author;
    private String isbm;
    private Integer quantity;
    private Boolean isAvailabe;
}
